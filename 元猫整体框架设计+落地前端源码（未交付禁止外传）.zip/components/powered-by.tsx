export function PoweredBy() {
  return <div className="text-center text-xs text-gray-400 py-2 opacity-70">Powered by 存客宝</div>
}

// 由存客宝技术团队开发

